### This website is a work in progress

As part of the CHARTER Horizon 2020 consortium, we are working on a project to identify key indicators of changes in biodiversity in Arctic regions over the past 12,000 years.

This is presently a work in progress and content on this website should be taken as draft and unfinished.